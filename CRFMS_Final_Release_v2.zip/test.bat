@echo offcd /d "%~dp0"if not exist out mkdir outif exist test-sources.txt del test-sources.txtfor /r src\main\java %%f in (*.java) do echo %%f>>test-sources.txtfor /r src\test\java %%f in (*.java) do echo %%f>>test-sources.txtjavac --release 17 -Xlint:all -d out @test-sources.txtif errorlevel 1 (pause & exit /b 1)java -cp out crfms.SecurityTestwhere python >nul 2>nul && python tools\validate_schema.pyif exist lib\sqlite-jdbc-3.50.3.0.jar if exist lib\slf4j-api-2.0.17.jar if exist lib\slf4j-nop-2.0.17.jar (
  java -cp "out;lib\sqlite-jdbc-3.50.3.0.jar;lib\slf4j-api-2.0.17.jar;lib\slf4j-nop-2.0.17.jar" crfms.DatabaseIntegrationTest
) else (
  echo ERROR: DatabaseIntegrationTest requires SQLite JDBC and SLF4J runtime dependencies in lib/.
  echo Run run.bat once with internet access to download them, or place the JARs in lib/.
  exit /b 1
) else (
  echo ERROR: DatabaseIntegrationTest requires SQLite JDBC and SLF4J runtime dependencies in lib/.
  echo Run run.bat once with internet access to download them, or place the JARs in lib/.
  exit /b 1
) else (
  echo ERROR: DatabaseIntegrationTest requires SQLite JDBC and SLF4J runtime dependencies in lib/.
  echo Run run.bat once with internet access to download them, or place the JARs in lib/.
  exit /b 1
)