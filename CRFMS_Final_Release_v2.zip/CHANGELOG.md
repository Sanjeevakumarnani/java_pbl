# CHANGELOG.md

## 2.1.0 ? Final Release (Completion)

### Added
- BASELINE_AUDIT.md, PROGRESS.md, DECISIONS.md, CHANGELOG.md scaffolding
- Test scripts now fail explicitly if SQLite JDBC/SLF4J runtime deps missing (no silent skip of DatabaseIntegrationTest)

### Verified
- Compilation with Java 17 + -Xlint:all: clean
- SecurityTest: 4 checks passed (PBKDF2, salts, verification)
- Schema validation (tools/validate_schema.py): 14 checks passed (16 tables, parity, constraints, FKs, defaults)
- DatabaseIntegrationTest: all extended integration checks passed (with JDBC deps in lib/)

### Pending (planned)
- Architecture refactor: Clock injection, model/dao/service/engine/bot/report layers (preserve behavior)
- Exact SuggestionEngine implementation per master prompt (ThresholdRule severity=limit-avg, TagRule severity=share, deterministic ordering, reference case)
- TextTokenizer with exact stop words from master prompt
- Full 14-rule book seeded; expanded seedDemo() (3 faculty, 10 students, 8 courses, 20+ FAQs, MID-TERM period with reference scenario)
- CSV injection safety, audit log viewer (last 50), department benchmark >=3 faculty, explicit course rating formula in docs
- Complete TC-01�TC-64 execution with evidence; F01�F28 status; full packaging (CRFMS_Final_Release.zip) with SHA256SUMS.txt
