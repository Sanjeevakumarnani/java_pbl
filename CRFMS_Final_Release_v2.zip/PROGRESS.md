# PROGRESS.md

## Current state
- Phase 0: Baseline audit complete (code, tests, docs, scripts, schema). SecurityTest and schema validation pass offline.
- Phase 1: Environment ready; created directories (out, dist, lib, logs, exports, backups). Compiled all sources with -Xlint:all (no warnings). 
- Phase 2-13: Plan defined; awaiting implementation.

## Recent actions
- Inspected all Java sources (CrfmsService 367 lines, MainFrame 111 lines, etc.), tests, docs, scripts, schema.
- Verified offline tests pass.
- Created BASELINE_AUDIT.md, DECISIONS.md scaffolding; prepared PROGRESS.md.

## Next actions
- Create BASELINE_AUDIT.md with detailed feature mapping.
- Fix test.sh/test.bat to not silently skip DatabaseIntegrationTest; add clear failure/labeling.
- Start architecture refactor (Clock injection, model/dao/service/engine/bot packages) preserving behavior.
- Implement exact SuggestionEngine, Tokenizer, 14 rules as per master prompt.
- Expand seedDemo() and add Clock support.
